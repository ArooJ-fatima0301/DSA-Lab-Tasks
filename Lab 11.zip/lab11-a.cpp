#include <iostream>
using namespace std;

class Queue {
    int data[10];
    int front, rear;

public:
    Queue() {
        front = -1;
        rear = -1;
    }

    void enqueue(int x) {
        if (rear == 9) {
            cout << "Queue full\n";
            return;
        }
        if (front == -1) front = 0;
        rear++;
        data[rear] = x;
    }

    void dequeue() {
        if (front == -1) {
            cout << "Queue empty\n";
            return;
        }
        data[front] = 0;
        front++;
    }

    void print() {
        cout << "Queue:\n";
        cout << "Front: " << front << ", Rear: " << rear << endl;
        
        if (front == -1) {
            cout << "Empty queue\n";
            return;
        }

        cout << "Contents: ";
        for (int i = front; i <= rear; i++) {
            cout << data[i];
            if (i < rear) cout << " -> ";
        }
        cout << endl;
    }
};

int main() {
    Queue obj;
    
    obj.enqueue(6);
    obj.enqueue(3);
    obj.enqueue(24);
    obj.enqueue(52);
    
    obj.dequeue();
    obj.print();

    return 0;
}