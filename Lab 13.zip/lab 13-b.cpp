#include <iostream>
using namespace std;

const int MAX = 100;
bool graph[MAX][MAX]; 
bool visited[MAX];

	void addEdge(int u, int v) 
	{
    	graph[u][v] = true;
    	graph[v][u] = true; 
}

	void dfsGraph(int node, int totalNodes) 
	{
    	visited[node] = true;
    	cout << node << " ";
    for (int neighbor = 1; neighbor <= totalNodes; neighbor++) {
        if (graph[node][neighbor] && !visited[neighbor]) {
            dfsGraph(neighbor, totalNodes);
        }
    }
}

int main() {
    int totalNodes = 5;

    addEdge(1, 2);
    addEdge(1, 3);
    addEdge(2, 4);
    addEdge(3, 5);

    cout << "DFS Traversal (Graph): ";
    dfsGraph(1, totalNodes);
    return 0;
}
