#include <iostream>
using namespace std;

const int MAX_CHILDREN = 10;

struct TreeNode 
{
    int val;
    TreeNode* children[MAX_CHILDREN];
    int childCount;

    TreeNode(int x) {
        val = x;
        childCount = 0;
        for (int i = 0; i < MAX_CHILDREN; i++) {
            children[i] = nullptr;
        }
    }
};

	void insertChild(TreeNode* parent, TreeNode* child) 
	{
    		if (parent->childCount < MAX_CHILDREN) 
			{
        parent->children[parent->childCount++] = child;
    } 
	else 
	{
        cout << "Cannot add more children to node " << parent->val << endl;
    }
}

	void dfsTree(TreeNode* root) 
	{
    	if (!root) return;
    cout << root->val << " ";
    for (int i = 0; i < root->childCount; i++) {
        dfsTree(root->children[i]);
    }
}

int main() {
    TreeNode* root = new TreeNode(1);
    TreeNode* child1 = new TreeNode(2);
    TreeNode* child2 = new TreeNode(3);
    TreeNode* child3 = new TreeNode(4);

    insertChild(root, child1);
    insertChild(root, child2);
    insertChild(child1, child3);

    cout << "DFS Traversal (Tree): ";
    dfsTree(root);
    return 0;
}
