#include <iostream>
using namespace std;

const int MAX = 10;
int graph[MAX][MAX];
bool visited[MAX];
int queue[MAX], front = 0, rear = -1;

	void bfsGraph(int start, int n) 
	{
    	visited[start] = true;
    	queue[++rear] = start;

    while (front <= rear) {
        int node = queue[front++];
        cout << node << " ";
        for (int i = 1; i <= n; i++) {
            if (graph[node][i] && !visited[i]) {
                visited[i] = true;
                queue[++rear] = i;
            }
        }
    }
}

int main() {
    int n = 5;
    graph[1][2] = graph[2][1] = 1;
    graph[1][3] = graph[3][1] = 1;
    graph[2][4] = graph[4][2] = 1;
    graph[3][5] = graph[5][3] = 1;

    cout << "BFS Graph: ";
    bfsGraph(1, n);
    return 0;
}
