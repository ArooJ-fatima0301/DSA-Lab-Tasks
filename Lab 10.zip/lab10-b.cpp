#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node(int d){
        data = d;
        next = nullptr;
    }
};

class Stack
{
private:
    Node *top;

public:
    Stack(){
        top = nullptr;
    }

    void push(int d)
    {
        Node *newNode = new Node(d);
        newNode->next = top;
        top = newNode;
    }

    void pop()
    {
        if (top == nullptr)
        {
            cout << "Stack Underflow!\n";
            return;
        }
        Node *temp = top;
        top = top->next;
        delete temp;
    }

    void pushAtStart(int d)
    {
        Node *newNode = new Node(d);
        if (top == nullptr)
        {
            top = newNode;
            return;
        }

        Node *temp = top;
        while (temp->next != nullptr)
        {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    void popAtStart()
    {
        if (top == nullptr)
        {
            cout << "Stack Underflow!\n";
            return;
        }

        if (top->next == nullptr)
        {
            delete top;
            top = nullptr;
            return;
        }

        Node *temp = top;
        Node *prev = nullptr;
        while (temp->next != nullptr)
        {
            prev = temp;
            temp = temp->next;
        }
        prev->next = nullptr;
        delete temp;
    }

    void print()
    {
        cout << "Stack:\n";
        if (top == nullptr)
        {
            cout << "Empty\n";
            return;
        }

        Node *temp = top;
        while (temp != nullptr)
        {
            cout << temp->data << "\n";
            temp = temp->next;
        }
    }
};

int main()
{
    Stack obj;

    obj.push(1);
    obj.push(2);
    obj.push(3);
    obj.push(4);

    obj.pushAtStart(8);
    obj.popAtStart();
    obj.pop();
    obj.push(9);

    obj.print();

    return 0;
}