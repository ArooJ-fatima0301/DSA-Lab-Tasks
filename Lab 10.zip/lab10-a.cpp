#include <iostream>
using namespace std;

class Stack {
private:
    int arr[10];
    int top;

public:
    Stack() {
        top = -1;
    }

    void push(int val) {
        if (top == 9) {
            cout << "Stack full\n";
            return;
        }
        top++;
        arr[top] = val;
    }

    void pop() {
        if (top == -1) {
            cout << "Stack empty\n";
            return;
        }
        top--;
    }

    void pushAtStart(int val) {
        if (top == 9) {
            cout << "Stack full\n";
            return;
        }
        for (int i = top; i >= 0; i--) {
            arr[i + 1] = arr[i];
        }
        top++;
        arr[0] = val;
    }

    void popAtStart() {
        if (top == -1) {
            cout << "Stack empty\n";
            return;
        }
        for (int i = 0; i < top; i++) {
            arr[i] = arr[i + 1];
        }
        top--;
    }

    void print() {
        cout << "Stack:\n";
        if (top == -1) {
            cout << "Empty\n";
            return;
        }
        for (int i = top; i >= 0; i--) {
            cout << arr[i] << endl;
        }
    }
};

int main() {
    Stack obj;

    obj.push(1);
    obj.push(2);
    obj.push(3);
    obj.push(4);

    obj.popAtStart();
    obj.pushAtStart(8);

    obj.pop();
    obj.print();

    return 0;
}