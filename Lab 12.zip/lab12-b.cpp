#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;

class Node
{
public:
    int value;
    Node *left;
    Node *right;
    int height;

    Node(int val)
    {
        value = val;
        left = nullptr;
        right = nullptr;
        height = 1;
    }
};

class AVLTree
{
private:
    Node *root;

    int height(Node *node)
    {
        return node ? node->height : 0;
    }

    int balanceFactor(Node *node)
    {
        return node ? height(node->left) - height(node->right) : 0;
    }

    void updateHeight(Node *node)
    {
        node->height = 1 + max(height(node->left), height(node->right));
    }

    Node *rotateRight(Node *y)
    {
        Node *x = y->left;
        Node *T2 = x->right;

        x->right = y;
        y->left = T2;

        updateHeight(y);
        updateHeight(x);

        return x;
    }

    Node *rotateLeft(Node *x)
    {
        Node *y = x->right;
        Node *T2 = y->left;

        y->left = x;
        x->right = T2;

        updateHeight(x);
        updateHeight(y);

        return y;
    }

    Node *balance(Node *node)
    {
        updateHeight(node);
        int bf = balanceFactor(node);

        if (bf > 1)
        {
            if (balanceFactor(node->left) < 0)
                node->left = rotateLeft(node->left);
            return rotateRight(node);
        }
        if (bf < -1)
        {
            if (balanceFactor(node->right) > 0)
                node->right = rotateRight(node->right);
            return rotateLeft(node);
        }
        return node;
    }

    Node *insert(Node *node, int val)
    {
        if (!node)
            return new Node(val);

        if (val < node->value)
            node->left = insert(node->left, val);
        else if (val > node->value)
            node->right = insert(node->right, val);
        else
            return node;

        return balance(node);
    }

    void printInorder(Node *node)
    {
        if (!node)
            return;
        printInorder(node->left);
        cout << node->value << " ";
        printInorder(node->right);
    }

    void printLevelOrder(Node *node)
    {
        if (!node)
            return;

        queue<Node *> q;
        q.push(node);

        while (!q.empty())
        {
            Node *current = q.front();
            q.pop();
            cout << current->value << " ";

            if (current->left)
            {
                q.push(current->left);
            }

            if (current->right)
            {
                q.push(current->right);
            }
        }
    }

public:
    AVLTree()
    {
        root = nullptr;
    }

    void add(int val)
    {
        root = insert(root, val);
    }

    void printInorder()
    {
        cout << "Inorder: ";
        printInorder(root);
    }

    void printLevelOrder()
    {
        cout << "\nLevel Order: ";
        printLevelOrder(root);
    }
};

int main()
{
    AVLTree Tree;

    Tree.add(1);
    Tree.add(2);
    Tree.add(4);
    Tree.add(3);
    Tree.add(6);
    Tree.add(5);
    Tree.add(7);

    Tree.printInorder();
    Tree.printLevelOrder();

    return 0;
}