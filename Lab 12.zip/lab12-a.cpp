#include <iostream>
#include <queue>
using namespace std;

struct Node
{
    int data;
    Node *left;
    Node *right;

    Node(int val)
    {
        data = val;
        left = nullptr;
        right = nullptr;
    }
};

class Tree
{
private:
    Node *root;

    Node *insert(Node *node, int val)
    {
        if (node == nullptr)
        {
            return new Node(val);
        }

        if (val < node->data)
        {
            node->left = insert(node->left, val);
        }
        else if (val > node->data)
        {
            node->right = insert(node->right, val);
        }

        return node;
    }

    void inorder(Node *node)
    {
        if (node == nullptr)
        {
            return;
        }

        inorder(node->left);
        cout << node->data << "  ";
        inorder(node->right);
    }

    void preOrder(Node *node)
    {
        if (node == nullptr)
        {
            return;
        }

        cout << node->data << "  ";
        preOrder(node->left);
        preOrder(node->right);
    }

    void postOrder(Node *node)
    {
        if (node == nullptr){
            return;
        }

        postOrder(node->left);
        postOrder(node->right);
        cout << node->data << "  ";
    }

public:
    Tree()
    {
        root = nullptr;
    }

    void insert(int val)
    {
        root = insert(root, val);
    }

    void inorder()
    {
        cout << "Inorder: ";
        inorder(root);
    }

    void preorder()
    {
        cout << "\nPreorder: ";
        preOrder(root);
    }

    void postorder()
    {
        cout << "\nPostorder: ";
        postOrder(root);
    }
};

int main()
{
    Tree Tree;

    Tree.insert(1);
    Tree.insert(2);
    Tree.insert(4);
    Tree.insert(3);
    Tree.insert(6);
    Tree.insert(5);
    Tree.insert(7);

    Tree.inorder();
    Tree.preorder(); 
    Tree.postorder();

    return 0;
}